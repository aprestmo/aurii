/**
 * Aurii HTTP API — Phase 2
 *
 * Routes:
 *   GET  /health
 *   GET  /schemas?dataset=
 *   POST /schemas?dataset=
 *   GET  /schemas/:id?dataset=
 *   GET  /entities?schema=&dataset=&limit=&offset=
 *   GET  /entities/:id
 *   PUT  /entities/:id            { data, expectedRevision, state? }
 *   GET  /entities/:id/revisions/:revision
 *   GET  /query?q=&dataset=
 *   POST /import/analyze          (multipart file upload)
 *   POST /import/run              { uploadId, schemaId, datasetId, mapping, transforms, dryRun }
 *   POST /import                  { path } — Phase 1 compatibility
 *   GET  /imports?dataset=
 *   GET  /stats?dataset=
 *
 * Dataset administration lives on the composed API app:
 *   /api/projects/:id/datasets
 *
 * Auth: if AURII_API_TOKEN is set, all routes except /health require
 * `Authorization: Bearer <token>`.
 */

import { cors } from "@elysiajs/cors";
import { swagger } from "@elysiajs/swagger";
import { Elysia } from "elysia";
import { mkdir } from "fs/promises";
import { join, resolve } from "path";
import { parse as parseYaml } from "yaml";
import { listCapabilities } from "../capabilities/registry";
import { getPlatformStore } from "../platform/store";
import { getImportScheduler } from "../schedule/scheduler";
import { isDatasetError } from "../dataset/errors";
import { countEntities, getEntity, getEntityRevision, listEntities, updateEntity } from "../entity/store";
import {
	isConcurrencyConflictError,
} from "../entity/revision";
import { analyzeContent } from "../import/analyze";
import { loadImportDefinition, runImport } from "../import/engine";
import type {
	FieldTransform,
	ImportDefinition,
	PipelineStep,
} from "../import/types";
import { isProjectError } from "../project/errors";
import { executeQuery, explainQuery } from "../query/executor";
import { getSchema, listSchemas, registerSchema } from "../schema/registry";
import type { SchemaDefinition } from "../schema/types";
import { DEFAULT_DATASET, getStorage } from "../storage";

export interface AppOptions {
	/** Bearer token required on protected routes. Unset = open (no auth). */
	apiToken?: string;
	/** Directory where `/import/analyze` writes uploaded files. */
	uploadDir?: string;
}

interface ImportRunRequest {
	uploadId: string;
	filename?: string;
	schemaId: string;
	datasetId?: string;
	mapping: Record<string, string>;
	transforms?: FieldTransform[];
	dryRun?: boolean;
	delimiter?: string;
}

// ── Plugins ──────────────────────────────────────────────────────────────────

/**
 * Adds YAML body parsing alongside the default JSON parser.
 */
const yamlBodyParser = new Elysia({ name: "yaml-body-parser" }).onParse(
	async ({ request, contentType }) => {
		if (contentType?.includes("yaml")) {
			return parseYaml(await request.text());
		}
	},
);

// ── App ───────────────────────────────────────────────────────────────────────

/**
 * Builds the Aurii Elysia app without binding it to a port.
 *
 * Kept separate from `.listen()` so tests can exercise every route with
 * `app.handle(request)` — no real network socket required — and so a
 * single process can host multiple independently-configured instances.
 */
export function buildApp(options: AppOptions = {}) {
	const API_TOKEN = options.apiToken ?? process.env["AURII_API_TOKEN"];
	const UPLOAD_DIR =
		options.uploadDir ??
		process.env["AURII_UPLOAD_DIR"] ??
		join(process.cwd(), ".aurii-uploads");

	return (
		new Elysia()
			.use(
				cors({
					origin: "*",
					methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
					allowedHeaders: ["Content-Type", "Authorization"],
				}),
			)
			.use(
				swagger({
					documentation: {
						info: {
							title: "Aurii Runtime API",
							version: "0.2.0",
							description:
								"Declarative Runtime for Structured Knowledge — HTTP API",
						},
						tags: [
							{ name: "Health", description: "Runtime health" },
							{ name: "Schemas", description: "Schema registry" },
							{ name: "Entities", description: "Entity store" },
							{ name: "Query", description: "Query Language" },
							{ name: "Import", description: "Import pipeline" },
							{ name: "Stats", description: "Storage statistics" },
						],
					},
				}),
			)
			.use(yamlBodyParser)
			.onError(({ error, set, code }) => {
				if (code === "NOT_FOUND") {
					set.status = 404;
					return { error: "Not Found" };
				}
				if (isProjectError(error)) {
					set.status = error.httpStatus;
					return {
						error: {
							code: error.code,
							message: error.message,
						},
					};
				}
				if (isDatasetError(error)) {
					set.status = error.httpStatus;
					return {
						error: {
							code: error.code,
							message: error.message,
						},
					};
				}
				set.status = 500;
				return { error: String(error) };
			})

			// ── Public ──────────────────────────────────────────────────────────────────
			.get(
				"/health",
				async () => {
					const storage = await getStorage();
					return {
						status: "ok",
						phase: "2",
						version: "0.2.0",
						storage: storage.kind,
						scheduler: { enabled: getImportScheduler().isStarted() },
						platformStore: { mode: getPlatformStore().kind },
						capabilities: listCapabilities().map((c) => ({
							id: c.id,
							kind: c.kind,
							status: c.status,
						})),
					};
				},
				{ tags: ["Health"] },
			)

			// ── Protected ─────────────────────────────────────────────────────────────
			// derive and onBeforeHandle are inlined here so TypeScript resolves `dataset`
			// correctly in all handler signatures below.
			.use(
				new Elysia()
					.derive(({ query }) => ({
						dataset:
							(query as Record<string, string | undefined>)["dataset"] ??
							DEFAULT_DATASET,
					}))
					.onBeforeHandle(({ headers, set }) => {
						if (!API_TOKEN) return;
						const auth =
							(headers as Record<string, string | undefined>)[
								"authorization"
							] ?? "";
						if (auth !== `Bearer ${API_TOKEN}`) {
							set.status = 401;
							return { error: "Unauthorized" };
						}
					})

					// Schemas (dataset-scoped; project write policy enforced in Core)
					.get("/schemas", async ({ query, dataset }) => {
						const scoped =
							(query as Record<string, string | undefined>)["dataset"] !==
							undefined;
						return listSchemas(scoped ? dataset : undefined);
					})
					.post("/schemas", async ({ body, dataset, set }) => {
						set.status = 201;
						return registerSchema(body as SchemaDefinition, dataset);
					})
					.get("/schemas/:id", async ({ params, dataset, set }) => {
						const schema = await getSchema(params.id, dataset);
						if (!schema) {
							set.status = 404;
							return { error: `Schema "${params.id}" not found` };
						}
						return schema;
					})

					// Entities
					.get("/entities", async ({ query, dataset, set }) => {
						const q = query as Record<string, string | undefined>;
						const schemaId = q["schema"];
						if (!schemaId) {
							set.status = 400;
							return { error: 'Missing "schema" parameter' };
						}
						const limit = parseInt(q["limit"] ?? "50", 10);
						const offset = parseInt(q["offset"] ?? "0", 10);
						const [entities, total] = await Promise.all([
							listEntities(schemaId, dataset, limit, offset),
							countEntities(schemaId, dataset),
						]);
						return { entities, total, limit, offset };
					})
					.get("/entities/:id", async ({ params, set }) => {
						const entity = await getEntity(params.id);
						if (!entity) {
							set.status = 404;
							return { error: `Entity "${params.id}" not found` };
						}
						set.headers["ETag"] = `"${entity.entityRevision}"`;
						return entity;
					})
					.put("/entities/:id", async ({ params, body, set }) => {
						const payload = body as {
							data?: Record<string, unknown>;
							expectedRevision?: number;
							state?: "active" | "archived" | "deleted";
							schemaVersion?: number;
						};
						if (!payload?.data || typeof payload.data !== "object") {
							set.status = 400;
							return { error: 'Body must include "data" object' };
						}
						if (
							typeof payload.expectedRevision !== "number" ||
							!Number.isInteger(payload.expectedRevision)
						) {
							set.status = 400;
							return {
								error: 'Body must include integer "expectedRevision"',
							};
						}
						try {
							const entity = await updateEntity(params.id, {
								data: payload.data,
								expectedRevision: payload.expectedRevision,
								...(payload.state !== undefined ? { state: payload.state } : {}),
								...(payload.schemaVersion !== undefined
									? { schemaVersion: payload.schemaVersion }
									: {}),
							});
							set.headers["ETag"] = `"${entity.entityRevision}"`;
							return entity;
						} catch (error) {
							if (isConcurrencyConflictError(error)) {
								set.status = 409;
								return {
									error: {
										code: error.code,
										message: error.message,
										expectedRevision: error.expectedRevision,
										currentRevision: error.currentRevision,
										entityId: error.entityId,
									},
								};
							}
							if (
								error instanceof Error &&
								error.message.includes("not found")
							) {
								set.status = 404;
								return { error: error.message };
							}
							throw error;
						}
					})
					.get(
						"/entities/:id/revisions/:revision",
						async ({ params, set }) => {
							const revision = Number.parseInt(params.revision, 10);
							if (!Number.isInteger(revision) || revision < 1) {
								set.status = 400;
								return { error: "Invalid revision" };
							}
							const snapshot = await getEntityRevision(params.id, revision);
							if (!snapshot) {
								set.status = 404;
								return {
									error: `Revision ${revision} not found for entity "${params.id}"`,
								};
							}
							return snapshot;
						},
					)

					// Query
					.get("/query", async ({ query, dataset, set }) => {
						const q = (query as Record<string, string | undefined>)["q"];
						if (!q) {
							set.status = 400;
							return { error: 'Missing query parameter "q"' };
						}
						const explain =
							(query as Record<string, string | undefined>)["explain"] ===
							"true";
						return executeQuery(q, dataset, { explain });
					})
					.get("/query/explain", async ({ query, set }) => {
						const q = (query as Record<string, string | undefined>)["q"];
						if (!q) {
							set.status = 400;
							return { error: 'Missing query parameter "q"' };
						}
						return explainQuery(q);
					})

					// Import: analyze (multipart file upload)
					.post("/import/analyze", async ({ request, set }) => {
						let rawForm: Awaited<ReturnType<Request["formData"]>>;
						try {
							rawForm = await request.formData();
						} catch {
							set.status = 400;
							return { error: "Expected multipart/form-data" };
						}
						const fileEntry = rawForm.get("file");
						if (!(fileEntry instanceof File)) {
							set.status = 400;
							return { error: 'Multipart field "file" is required' };
						}

						const content = await fileEntry.text();
						const analysis = analyzeContent(fileEntry.name, content);

						await mkdir(UPLOAD_DIR, { recursive: true });
						const uploadId = crypto.randomUUID();
						const ext = analysis.format === "json" ? "json" : "csv";
						await Bun.write(join(UPLOAD_DIR, `${uploadId}.${ext}`), content);

						return { uploadId, filename: fileEntry.name, ...analysis };
					})

					// Import: run (wizard)
					.post("/import/run", async ({ body, dataset, set }) => {
						const b = body as ImportRunRequest | null;
						if (!b?.uploadId || !b?.schemaId || !b?.mapping) {
							set.status = 400;
							return { error: "Required: uploadId, schemaId, mapping" };
						}

						const csvPath = join(UPLOAD_DIR, `${b.uploadId}.csv`);
						const jsonPath = join(UPLOAD_DIR, `${b.uploadId}.json`);
						const isCsv = await Bun.file(csvPath).exists();
						const isJson = !isCsv && (await Bun.file(jsonPath).exists());
						if (!isCsv && !isJson) {
							set.status = 404;
							return { error: `Upload "${b.uploadId}" not found` };
						}

						const steps: PipelineStep[] = [{ type: "map", mapping: b.mapping }];
						if (b.transforms && b.transforms.length > 0) {
							steps.push({ type: "transform", transforms: b.transforms });
						}
						steps.push({ type: "validate" }, { type: "persist" });

						const sourceOptions = b.delimiter
							? { delimiter: b.delimiter }
							: undefined;
						const def: ImportDefinition = {
							id: `wizard-${b.uploadId}`,
							name: b.filename ?? `Wizard import ${b.uploadId}`,
							schema: b.schemaId,
							source: {
								type: isCsv ? "csv" : "json",
								path: isCsv ? csvPath : jsonPath,
								...(sourceOptions ? { options: sourceOptions } : {}),
							},
							pipeline: { steps },
						};

						return runImport(def, "/", {
							datasetId: b.datasetId ?? dataset,
							dryRun: b.dryRun ?? false,
						});
					})

					// Import: Phase 1 compatibility
					.post("/import", async ({ body, dataset, set }) => {
						const b = body as { path?: string } | null;
						if (!b?.path) {
							set.status = 400;
							return { error: 'Provide "path" to an import YAML file' };
						}
						const def = await loadImportDefinition(
							resolve(process.cwd(), b.path),
						);
						return runImport(def, process.cwd(), { datasetId: dataset });
					})

					// Import history
					.get("/imports", async ({ query, dataset }) => {
						const storage = await getStorage();
						const limit = parseInt(
							(query as Record<string, string | undefined>)["limit"] ?? "20",
							10,
						);
						return storage.listImportRuns(dataset, limit);
					})

					// Stats
					.get("/stats", async ({ dataset }) => {
						const storage = await getStorage();
						return storage.getStats(dataset);
					}),
			)
	);
}

// ── Entrypoint ────────────────────────────────────────────────────────────────
// Only bind a real port when this file is executed directly (`bun run serve`),
// never on import — this is what lets tests call `buildApp().handle(request)`
// in-process without a network socket.

if (import.meta.main) {
	const PORT = parseInt(process.env["PORT"] ?? "3000", 10);
	const API_TOKEN = process.env["AURII_API_TOKEN"];

	const app = buildApp().listen({
		port: PORT,
		maxRequestBodySize: 100 * 1024 * 1024, // 100 MB uploads
	});

	console.log(`Aurii API running on http://localhost:${app.server?.port}`);
	console.log(`Storage: ${process.env["AURII_STORAGE"] ?? "sqlite"}`);
	console.log(
		`Auth: ${API_TOKEN ? "token required" : "open (set AURII_API_TOKEN to protect)"}`,
	);
}
